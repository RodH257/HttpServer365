#!/usr/bin/python

import cgitb, cgi
cgitb.enable()

print("Content-type: text/html")
print("")

form = cgi.FieldStorage()
if "file" not in form:
    print("<H1>Error</H1>")
    print("<P>Please fill in the form</P>")
else:
    filepath = form["file"].value
    try:
        with open(filepath) as fh:
            for line in fh:
                print(line.replace("\n","<br>"))
    except IOError as e:
        print("<P>Failed to open %s</P>" % filepath)
